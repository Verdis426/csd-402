
/**
 * File: FanTest.java
 * Course: CSD-402
 * Module: 6
 * Description: Tests the Fan class using
 * the default and parameterized constructors.
 */

public class FanTest {

    public static void main(String[] args) {

        // Create a fan using the default constructor
        Fan fan1 = new Fan();

        System.out.println("=== Fan 1: Default Fan ===");
        System.out.println(fan1);

        // Create a fan using the argument constructor
        Fan fan2 = new Fan(Fan.FAST, true, 10, "blue");

        System.out.println("\n=== Fan 2: Custom Fan ===");
        System.out.println(fan2);

        // Test setter methods
        fan1.setSpeed(Fan.MEDIUM);
        fan1.setOn(true);
        fan1.setRadius(8);
        fan1.setColor("red");

        System.out.println("\n=== Fan 1: Updated Settings ===");
        System.out.println(fan1);

        // Test getter methods
        System.out.println("\n=== Testing Getter Methods ===");
        System.out.println("Speed: " + fan1.getSpeed());
        System.out.println("On: " + fan1.isOn());
        System.out.println("Radius: " + fan1.getRadius());
        System.out.println("Color: " + fan1.getColor());
    }
}
