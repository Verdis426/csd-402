
/**
 * File: Fan.java
 * Course: CSD-402
 * Module: 6
 * Description: Demonstrates the Fan class using
 * constructors, constants, getters, setters,
 * and the toString() method.
 */

public class Fan {

    // Constants for fan speed
    public static final int STOPPED = 0;
    public static final int SLOW = 1;
    public static final int MEDIUM = 2;
    public static final int FAST = 3;

    // Private instance fields
    private int speed;
    private boolean on;
    private double radius;
    private String color;

    // No-argument constructor
    public Fan() {
        speed = STOPPED;
        on = false;
        radius = 6;
        color = "white";
    }

    // Constructor with arguments
    public Fan(int speed, boolean on,
               double radius, String color) {
        setSpeed(speed);
        this.on = on;
        setRadius(radius);
        setColor(color);
    }

    // Getter and setter for speed
    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        if (speed >= STOPPED && speed <= FAST) {
            this.speed = speed;
        }
    }

    // Getter and setter for on
    public boolean isOn() {
        return on;
    }

    public void setOn(boolean on) {
        this.on = on;
    }

    // Getter and setter for radius
    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        if (radius > 0) {
            this.radius = radius;
        }
    }

    // Getter and setter for color
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        if (color != null && !color.isBlank()) {
            this.color = color;
        }
    }

    // Return the fan's current state
    @Override
    public String toString() {
        return "Fan speed: " + speed
                + "\nFan on: " + on
                + "\nFan radius: " + radius
                + "\nFan color: " + color;
    }
}
